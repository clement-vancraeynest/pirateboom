$(function(){

  console.log('------ G  A  M  E.js');
  
  gridBuilder(12);
  navigateMap();


});


function gridBuilder(size){
	$('.grid').empty();
	caseSize = 100; //en px
	insideWidth = Math.hypot(caseSize, caseSize);
	colNb = size;

	for (var i = 0; i < colNb; i++) {

	    $('.grid').append('<ul></ul>');
	    
	    for (var a = 0; a < colNb; a++) {
	    	
	    	if(i == 4 & a == 3){
	    		$('.grid ul').eq(i).append('<li><div class="inside"><div class="inside-wrap"><img src="img/01.png" alt=""/></div></div></li>');
	    	}else if( i == 6 & a == 8){
	    		$('.grid ul').eq(i).append('<li><div class="inside"><div class="inside-wrap"><img src="img/02.png" alt=""/></div></div></li>');
	    	}else{
	    		$('.grid ul').eq(i).append('<li></li>');
	    	}
		}
	}
	
	$('.grid').width(colNb*caseSize+'px');
	$('.grid-floor').width(colNb*caseSize+'px').height(colNb*caseSize+'px');
	$('.grid ul li .inside').width(insideWidth+'px').height(insideWidth+'px');

	$('.grid ul li').click(function(){
		$('.grid ul li').removeClass('active');
		$(this).addClass('active');
	});
	
}


function navigateMap(){

	var isDragging = false, fromPoint = {x:0,y:0}, move= {left:0,top:0}, map={ current:{x:0,y:0}, zoom:1};
	$(".game").mousedown(function(event) {
	    isDragging = true;

    	fromPoint.y = event.clientY;
	    fromPoint.x = event.clientX;

	    if( event.which == 2 ) {
	      event.preventDefault();
	      map.zoom = 1;
	      $('.map').css({transform: 'translate('+move.left+'px, '+move.top+'px) scale('+map.zoom+')'});
	   	}	

	})
	.mousemove(function(event) {
	    if(isDragging){
	    	move.left = map.current.x + (event.clientX - fromPoint.x);
		    move.top = map.current.y + ( event.clientY - fromPoint.y);
	    	console.log("mousemove *", move.left, move.top);
		    $('.map').css({transform: 'translate('+move.left+'px, '+move.top+'px) scale('+map.zoom+')'});

		}
	 })
	.mouseup(function(event) {
	    var wasDragging = isDragging;

	    map.current.x = move.left;
	    map.current.y = move.top;

	    isDragging = false;
	});

	 $('.game').bind('mousewheel', function(e){
        if(e.originalEvent.wheelDelta /120 > 0) {
        	map.zoom = map.zoom+0.1;
        	if(map.zoom >= 2){
        		map.zoom = 2;
        	}
            $('.map').css({transform: 'translate('+move.left+'px, '+move.top+'px) scale('+map.zoom+')'});
        }
        else{
        	map.zoom = map.zoom-0.1;
        	if(map.zoom <= 0.7){
        		map.zoom = 0.7;
        	}
            $('.map').css({transform: 'translate('+move.left+'px, '+move.top+'px) scale('+map.zoom+')'});
        }
    });

}

